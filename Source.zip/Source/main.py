# # Effectively runs at High Internet Speed
#
# import time
# import random
# import aiohttp
# import asyncio
# import requests
# from bs4 import BeautifulSoup
# from googlesearch import search
# from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
# from selenium.webdriver.common.by import By
# from webdriver_manager.chrome import ChromeDriverManager
# from selenium.webdriver.chrome.service import Service as ChromeService
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.webdriver.common.keys import Keys
# import pandas as pd
#
#
# # Get the page source and parse it with BeautifulSoup
# async def get_page_source(driver, url):
#     driver.get(url)
#     driver.maximize_window()
#
#     # Wait until the dropdown is present
#     dropdown_locator = (By.CLASS_NAME, 'mt-1')
#     WebDriverWait(driver, 10).until(EC.presence_of_element_located(dropdown_locator))
#
#     dropdown = driver.find_element(*dropdown_locator)
#     dropdown.click()
#     dropdown.send_keys(Keys.DOWN)
#     dropdown.send_keys(Keys.DOWN)
#     dropdown.send_keys(Keys.ENTER)
#     await asyncio.sleep(1)
#     return driver.page_source
#
#
# # Fetch the data from the source page returned from get_page_source() with the bs4 and selenium webdriver
# async def fetch_data(session, driver, url):
#     page_source = await get_page_source(driver, url)
#     soup = BeautifulSoup(page_source, 'lxml')
#     table = soup.find('table', class_='w-full divide-y divide-gray-300 lg:table-fixed')
#     table_body = table.find('tbody', class_='divide-y divide-gray-200 bg-white')
#     rows = table_body.find_all('tr')
#
#     data_list = []
#     cloud_domain = driver.find_elements(By.XPATH, "//a[@class='underline hover:text-tangelo']")
#     random_indices = random.sample(range(len(cloud_domain)), len(cloud_domain))
#
#     for random_index in random_indices:
#         p = cloud_domain[random_index]
#         page = p.text.replace(" ", "-")
#         company_url = f"https://www.employbl.com/companies/{page}"
#         r = requests.get(company_url)
#         bs = BeautifulSoup(r.text, "html.parser")
#         # Find the link in the company page
#         link = bs.find('a',
#                        class_="flex items-center justify-center text-base font-medium text-indigo-600 sm:justify-start")
#
#         if link:
#             href_value = link.get('href').replace("https://", "").replace("www.", "").replace("/", "")
#             to_do_search = href_value.split('.')[0]
#             query = to_do_search
#             result = list(search(query))
#             href_url = f"www.{href_value}"
#             data_list.append(href_url)
#
#         if len(data_list) >= 500:
#             break
#
#     return data_list
#
#
# async def write_to_excel(data_list, url):
#     # Create a DataFrame and write it to an Excel file
#     filename = f'({url.replace("https://", "").replace("/", "_")})_Data.xlsx'
#     df = pd.DataFrame({"Website": data_list})
#     df.to_excel(filename, index=False, engine='openpyxl')
#     print(f'Data for {url} has been written to {filename}')
#
#
# async def main():
#     # List of URLs to extract data from
#     urls = ['amazon-web-services',
#             'google-cloud-platform',
#             'microsoft-azure']
#     chrome_options = Options()
#     # Set up Chrome WebDriver
#     driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=chrome_options)
#
#     async with aiohttp.ClientSession() as session:
#         for url in urls:
#             print(f"Extracting data from: {url}")
#             # Fetch data and write to Excel for each URL
#             data_list = await fetch_data(session, driver, f'https://www.employbl.com/company-collections/{url}')
#             await write_to_excel(data_list, url)
#             print(f"Extraction from {url} is successful.\n")
#     # Quit the Chrome WebDriver
#     driver.quit()
#     print("Extraction of data is complete.")
#
#
# if __name__ == "__main__":
#     # Run the main function using asyncio
#     asyncio.run(main())

#
# import time
# import random
# import asyncio
# import requests
# from bs4 import BeautifulSoup
# from googlesearch import search
# from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
# from selenium.webdriver.common.by import By
# from webdriver_manager.chrome import ChromeDriverManager
# from selenium.webdriver.chrome.service import Service as ChromeService
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.webdriver.common.keys import Keys
# import pandas as pd
#
#
# # Get the page source and parse it with BeautifulSoup
# async def get_page_source(driver, url):
#     driver.get(url)
#     driver.maximize_window()
#     # Wait until the dropdown is present
#     dropdown_locator = (By.CLASS_NAME, 'mt-1')
#     WebDriverWait(driver, 10).until(EC.presence_of_element_located(dropdown_locator))
#
#     dropdown = driver.find_element(*dropdown_locator)
#     dropdown.click()
#     dropdown.send_keys(Keys.DOWN)
#     dropdown.send_keys(Keys.DOWN)
#     dropdown.send_keys(Keys.ENTER)
#     await asyncio.sleep(1)
#     return driver.page_source
#
#
# # Fetch the data from the source page returned from get_page_source() with the bs4 and selenium webdriver
# async def fetch_data(driver, url):
#     page_source = await get_page_source(driver, url)
#
#     data_list = []
#     cloud_domain = driver.find_elements(By.XPATH, "//a[@class='underline hover:text-tangelo']")
#     random_indices = random.sample(range(len(cloud_domain)), len(cloud_domain))
#
#     for random_index in random_indices:
#         p = cloud_domain[random_index]
#         page = p.text.replace(" ", "-")
#         company_url = f"https://www.employbl.com/companies/{page}"
#         r = requests.get(company_url)
#         bs = BeautifulSoup(r.text, "html.parser")
#         # Find the link in the company page
#         link = bs.find('a',
#                        class_="flex items-center justify-center text-base font-medium text-indigo-600 sm:justify-start")
#
#         if link:
#             href_value = link.get('href').replace("https://", "").replace("www.", "").replace("/", "")
#             to_do_search = href_value.split('.')[0]
#             query = to_do_search + "linkedIn ceo"
#             result = list(search(query))
#             print(result[0])
#             href_url = f"www.{href_value}"
#             data_list.append(href_url)
#
#         if len(data_list) >= 500:
#             break
#
#     return data_list
#
#
# async def write_to_excel(data_list, url):
#     # Create a DataFrame and write it to an Excel file
#     filename = f'({url.replace("https://", "").replace("/", "_")})_Data.xlsx'
#     df = pd.DataFrame({"Website": data_list})
#     df.to_excel(filename, index=False, engine='openpyxl')
#     print(f'Data for {url} has been written to {filename}')
#
#
# async def main():
#     # List of URLs to extract data from
#     urls = ['amazon-web-services',
#             'google-cloud-platform',
#             'microsoft-azure']
#     chrome_options = Options()
#     # Set up Chrome WebDriver
#     driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=chrome_options)
#
#     for url in urls:
#         print(f"Extracting data from: {url}")
#         # Fetch data and write to Excel for each URL
#         data_list = await fetch_data(driver, f'https://www.employbl.com/company-collections/{url}')
#         await write_to_excel(data_list, url)
#         print(f"Extraction from {url} is successful.\n")
#
#     # Quit the Chrome WebDriver
#     driver.quit()
#     print("Extraction of data is complete.")
#
#
# if __name__ == "__main__":
#     # Run the main function using asyncio
#     asyncio.run(main())
#

import time
import random
import asyncio
import requests
import httpx
from bs4 import BeautifulSoup
from selenium import webdriver
from urllib.parse import urlencode
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import pandas as pd


# Get the page source and parse it with BeautifulSoup
async def get_page_source(driver, url):
    driver.get(url)
    # Wait until the dropdown is present
    dropdown_locator = (By.CLASS_NAME, 'mt-1')
    WebDriverWait(driver, 10).until(EC.presence_of_element_located(dropdown_locator))

    dropdown = driver.find_element(*dropdown_locator)
    dropdown.click()
    dropdown.send_keys(Keys.DOWN)
    dropdown.send_keys(Keys.DOWN)
    dropdown.send_keys(Keys.ENTER)

    # Wait for a short time to allow the page to load
    await asyncio.sleep(2)

    try:
        # Maximize the window after a short delay
        await asyncio.sleep(1)
        driver.maximize_window()
    except Exception as e:
        print(f"Failed to maximize window: {e}")

    return driver.page_source


# Fetch the data from the source page returned from get_page_source() with the bs4 and selenium webdriver
async def fetch_data(driver, url, API_KEY):
    page_source = await get_page_source(driver, url)
    company_data = []
    cloud_domain = driver.find_elements(By.XPATH, "//a[@class='underline hover:text-tangelo']")
    random_indices = random.sample(range(len(cloud_domain)), len(cloud_domain))

    API_KEY = '586635fb-f0cb-4cde-9279-ed1fc073b873'
    async with httpx.AsyncClient(timeout=10) as client:
        for random_index in random_indices:
            p = cloud_domain[random_index]
            page = p.text.replace(" ", "-")
            company_url = f"https://www.employbl.com/companies/{page}"
            try:
                r = await client.get(company_url)
                r.raise_for_status()
                bs = BeautifulSoup(r.text, "html.parser")
                link = bs.find('a',
                               class_="flex items-center justify-center text-base font-medium text-indigo-600 "
                                      "sm:justify-start")

                if link:
                    href_value = link.get('href').replace("https://", "").replace("www.", "").replace("/", "")
                    to_do_search = href_value.split('.')[0]
                    query = to_do_search
                    url = f'https://www.google.com/search?q={query}+CEO+linkedin+profile+current'
                    proxy_params = {
                        'api_key': API_KEY,
                        'url': url,
                    }
                    response = requests.get(
                        url='https://proxy.scrapeops.io/v1/',
                        params=urlencode(proxy_params),
                        timeout=10,
                    )
                    response.raise_for_status()
                    soup = BeautifulSoup(response.text, 'html.parser')
                    links = soup.find_all('a', {'jsname': 'UWckNb'})
                    ceo_name = ""
                    h3_tags = soup.find_all('h3', class_='LC20lb MBeuO DKV0Md')
                    for h3_tag in h3_tags:
                        ceo_name += h3_tag.text.strip()
                    ceo_name = ceo_name.split('-')[0].strip()

                    link = links[0].get('href')
                    company_data.append({"Website": f"www.{href_value}", "Ceo_LinkedIn": link, "CEO_Name": ceo_name})

                if len(company_data) >= 200:
                    break

            except (httpx.HTTPError, requests.RequestException, Exception) as e:
                print(f"Error while fetching data: {e}")

    return company_data


async def write_to_excel(company_data, url):
    # Create a DataFrame and write it to an Excel file
    filename = f'({url.replace("https://", "").replace("/", "_")})_Data.xlsx'
    df = pd.DataFrame(company_data)
    df.to_excel(filename, index=False, engine='openpyxl')
    print(f'Data for {url} has been written to {filename}')


async def main():
    # List of URLs to extract data from
    urls = ['amazon-web-services',
            'google-cloud-platform',
            'microsoft-azure']
    chrome_options = Options()
    # Set up Chrome WebDriver
    driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=chrome_options)
    for url in urls:
        print(f"Extracting data from: {url}")
        # Fetch data and write to Excel for each URL
        company_data = await fetch_data(driver, f'https://www.employbl.com/company-collections/{url}', API_KEY)
        await write_to_excel(company_data, url)
        print(f"Extraction from {url} is successful.\n")
    # Quit the Chrome WebDriver
    driver.quit()
    print("Extraction of data is complete.")


if __name__ == "__main__":
    # Run the main function using asyncio
    asyncio.run(main())
